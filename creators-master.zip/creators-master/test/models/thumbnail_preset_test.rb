require 'test_helper'

class ThumbnailPresetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
