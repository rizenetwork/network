require 'test_helper'

class GalleryImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
