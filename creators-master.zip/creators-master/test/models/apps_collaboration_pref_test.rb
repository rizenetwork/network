require 'test_helper'

class AppsCollaborationPrefTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
