require 'test_helper'

class TxTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
