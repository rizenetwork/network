require 'test_helper'

class PaypalNotificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
