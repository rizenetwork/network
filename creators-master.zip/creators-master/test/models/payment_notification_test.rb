require 'test_helper'

class PaymentNotificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
