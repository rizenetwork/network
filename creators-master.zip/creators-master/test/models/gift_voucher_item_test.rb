require 'test_helper'

class GiftVoucherItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
