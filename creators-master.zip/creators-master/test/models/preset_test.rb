require 'test_helper'

class PresetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
