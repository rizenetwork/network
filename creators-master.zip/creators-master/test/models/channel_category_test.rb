require 'test_helper'

class ChannelCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
