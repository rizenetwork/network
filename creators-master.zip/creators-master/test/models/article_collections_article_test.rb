require 'test_helper'

class ArticleCollectionsArticleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
