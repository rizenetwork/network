require 'test_helper'

class ArticleCollectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
