require 'test_helper'

class MotionGraphicTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
