require 'test_helper'

class ViewsViaNokoJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
