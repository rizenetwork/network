require 'test_helper'

class ParseYoutubeJsonJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
