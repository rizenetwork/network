require 'test_helper'

class SubsViaNokoJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
