//= require site

$(function() {

	$('.ui.video').video();
});