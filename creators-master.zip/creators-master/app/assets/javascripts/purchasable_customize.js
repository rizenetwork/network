//= require spectrum
//= require rangeslider
//= require fileupload
//= require gallery