//= require webfont
//= require spectrum
//= require rangeslider
//= require ocanvas.min
//= require fileupload
//= require gallery