class Admin::AdminController < AdminController

  def index
    # TODO: stuff for admin dashboard
  end
  
end