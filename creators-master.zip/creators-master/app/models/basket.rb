class Basket < Order
end