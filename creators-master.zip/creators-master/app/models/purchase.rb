class Purchase < Order
  
  def locked
    true
  end
  
end