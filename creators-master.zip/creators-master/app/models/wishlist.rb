class Wishlist < Order
end