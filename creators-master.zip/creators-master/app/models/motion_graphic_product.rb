class MotionGraphicProduct < Product
  
end