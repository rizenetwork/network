class SongProduct < Product
#  def can_customize
#    true
#  end
#  
  def has_gallery
    false
  end
end