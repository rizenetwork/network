module MotionGraphicsHelper
	include ActsAsTaggableOn::TagsHelper
end
